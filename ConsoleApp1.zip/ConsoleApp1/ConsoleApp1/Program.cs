﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader streamReader = new StreamReader("t.txt");
            string str;
            Console.WriteLine("Содержимое тестового файла:");
            while (streamReader.EndOfStream != true)
            {
                str = streamReader.ReadLine();
                Console.WriteLine(str);
            }
            Console.WriteLine();

            StreamReader streamReader1 = new StreamReader("t.txt");
            Queue queue = new Queue();
            Queue queue1 = new Queue();
            string[] strmas = streamReader1.ReadToEnd().Split();

            for (int i = 0; i < strmas.Length; i++)
            {
                int r = 0;
                if (int.TryParse(strmas[i], out r))
                {
                    if (r > 0)
                    {
                        queue.Enqueue(r);
                    }
                    if (r < 0)
                    {
                        queue1.Enqueue(r);
                    }
                }
            }
            Console.Write("Положительные числа: ");
            foreach (int c in queue)
            {
                Console.Write(" " + c);
            }
            Console.Write("\nОтрицательные числа: ");
            foreach (int c in queue1)
            {
                Console.Write(" " + c);
            }
            Console.ReadKey();
        }
    }
}
