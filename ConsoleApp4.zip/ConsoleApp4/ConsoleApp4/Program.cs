﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader streamReader = new StreamReader("t.txt");
            string str;
            Console.WriteLine("Содержимое тестового файла:");
            while (streamReader.EndOfStream != true)
            {
                str = streamReader.ReadLine();
                Console.WriteLine(str);
            }
            Console.WriteLine();

            StreamReader streamReader1 = new StreamReader("t.txt");
            Stack stack = new Stack();
            Stack stack1 = new Stack();
            string[] strmas = streamReader1.ReadToEnd().Split();
            int min = 0;



            int max = 0;
            for (int i = 0; i < strmas.Length; i++)
            {
                if (max < Convert.ToInt32(strmas[i]))
                {
                    max = Convert.ToInt32(strmas[i]);
                }
            }
            for (int i = 0; i < strmas.Length; i++)
            {
                if (Convert.ToInt32(strmas[i]) != max)
                {
                    min = Convert.ToInt32(strmas[i]);
                    stack1.Push(min);
                }
            }
            stack.Push(max);
            Console.Write("Максимум: ");
            foreach (int c in stack)
            {
                Console.Write(" " + c);
            }
            Console.Write("\nМинимум: ");
            foreach (int c in stack1)
            {
                Console.Write(" " + c);
            }
            Console.ReadKey();
        }
    }
}
